Save your completed Power BI report (.pbix) in this folder after connecting to the cleaned data or MySQL database.
