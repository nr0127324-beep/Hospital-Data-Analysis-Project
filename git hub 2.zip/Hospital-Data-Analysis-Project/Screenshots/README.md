Save screenshots of your completed Power BI dashboard in this folder.
