"""
Hospital Data Analysis - beginner Python script
Run from this folder or update CSV_PATH to your CSV location.
Install: pip install pandas numpy matplotlib
"""
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

CSV_PATH = Path(__file__).resolve().parents[1] / "Dataset" / "hospital_data_1000_rows.csv"
df = pd.read_csv(CSV_PATH)

print("First five rows:")
print(df.head())
print("\nDataset shape:", df.shape)
print("\nData types and non-null counts:")
df.info()
print("\nMissing values:")
print(df.isna().sum())
print("\nDuplicate patient IDs:", df["Patient_ID"].duplicated().sum())

# Clean duplicate IDs and missing values
df = df.drop_duplicates(subset="Patient_ID").copy()
df["Doctor"] = df["Doctor"].fillna("Unknown")
df["Payment_Mode"] = df["Payment_Mode"].fillna("Unknown")
df["Satisfaction"] = df["Satisfaction"].fillna(df["Satisfaction"].median())

# Convert dates
df["Admission_Date"] = pd.to_datetime(df["Admission_Date"], errors="coerce")
df["Discharge_Date"] = pd.to_datetime(df["Discharge_Date"], errors="coerce")
df["Admission_Year"] = df["Admission_Date"].dt.year
df["Admission_Month"] = df["Admission_Date"].dt.to_period("M").astype(str)

# Basic analysis
print("\nTotal patients:", df["Patient_ID"].nunique())
print("Total treatment cost:", round(df["Treatment_Cost"].sum(), 2))
print("Average treatment cost:", round(df["Treatment_Cost"].mean(), 2))
print("Average patient age:", round(df["Age"].mean(), 2))
print("Average stay days:", round(df["Stay_Days"].mean(), 2))
print("\nPatients by department:")
print(df["Department"].value_counts())
print("\nTreatment cost by department:")
print(df.groupby("Department")["Treatment_Cost"].sum().sort_values(ascending=False))

# Save cleaned data for MySQL import / Power BI
output_path = CSV_PATH.parent / "hospital_cleaned_data.csv"
df.to_csv(output_path, index=False)
print(f"\nCleaned dataset saved to: {output_path}")

# Save a simple department chart
chart = df.groupby("Department")["Patient_ID"].count().sort_values()
chart.plot(kind="barh", title="Patients by Department", xlabel="Number of patients")
plt.tight_layout()
chart_path = CSV_PATH.parent.parent / "Screenshots" / "patients_by_department.png"
plt.savefig(chart_path, dpi=150)
print(f"Chart saved to: {chart_path}")
