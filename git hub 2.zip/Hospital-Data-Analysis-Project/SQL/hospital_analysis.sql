-- Hospital Data Analysis Project
-- Run this script in MySQL Workbench.

CREATE DATABASE IF NOT EXISTS hospital_db;
USE hospital_db;

DROP TABLE IF EXISTS patients;

CREATE TABLE patients (
    Patient_ID VARCHAR(20) PRIMARY KEY,
    Name VARCHAR(100),
    Age INT,
    Gender VARCHAR(10),
    Department VARCHAR(50),
    Admission_Date DATE,
    Discharge_Date DATE,
    Diagnosis VARCHAR(100),
    Treatment_Cost DECIMAL(10,2),
    Doctor VARCHAR(100),
    Stay_Days INT,
    Payment_Mode VARCHAR(30),
    Satisfaction DECIMAL(3,1)
);

-- After cleaning the CSV with the Python script, import
-- hospital_cleaned_data.csv into this table using MySQL Workbench:
-- hospital_db > right-click patients > Table Data Import Wizard.

-- 1. Total patient records
SELECT COUNT(*) AS total_patients FROM patients;

-- 2. Department-wise patient count
SELECT Department, COUNT(*) AS total_patients
FROM patients
GROUP BY Department
ORDER BY total_patients DESC;

-- 3. Total treatment cost by department
SELECT Department, SUM(Treatment_Cost) AS total_treatment_cost
FROM patients
GROUP BY Department
ORDER BY total_treatment_cost DESC;

-- 4. Average treatment cost by department
SELECT Department, ROUND(AVG(Treatment_Cost), 2) AS average_treatment_cost
FROM patients
GROUP BY Department
ORDER BY average_treatment_cost DESC;

-- 5. Monthly admissions
SELECT DATE_FORMAT(Admission_Date, '%Y-%m') AS admission_month,
       COUNT(*) AS total_admissions
FROM patients
GROUP BY DATE_FORMAT(Admission_Date, '%Y-%m')
ORDER BY admission_month;

-- 6. Average length of stay
SELECT ROUND(AVG(Stay_Days), 2) AS average_stay_days
FROM patients;

-- 7. Patient satisfaction by department
SELECT Department, ROUND(AVG(Satisfaction), 2) AS average_satisfaction
FROM patients
GROUP BY Department
ORDER BY average_satisfaction DESC;

-- 8. Doctor-wise patient count
SELECT Doctor, COUNT(*) AS total_patients
FROM patients
GROUP BY Doctor
ORDER BY total_patients DESC;

-- 9. Revenue by payment method
SELECT Payment_Mode, SUM(Treatment_Cost) AS total_treatment_cost
FROM patients
GROUP BY Payment_Mode
ORDER BY total_treatment_cost DESC;

-- 10. Five highest treatment costs
SELECT Patient_ID, Name, Department, Treatment_Cost
FROM patients
ORDER BY Treatment_Cost DESC
LIMIT 5;

-- 11. Patients older than 50
SELECT Patient_ID, Name, Age, Department
FROM patients
WHERE Age > 50
ORDER BY Age DESC;

-- 12. Patients with satisfaction below 3
SELECT Patient_ID, Name, Department, Satisfaction
FROM patients
WHERE Satisfaction < 3
ORDER BY Satisfaction;

-- 13. Second-highest distinct treatment cost
SELECT MAX(Treatment_Cost) AS second_highest_cost
FROM patients
WHERE Treatment_Cost < (SELECT MAX(Treatment_Cost) FROM patients);

-- 14. Admission counts by gender
SELECT Gender, COUNT(*) AS total_patients
FROM patients
GROUP BY Gender;

-- 15. Year-wise treatment cost
SELECT YEAR(Admission_Date) AS admission_year,
       SUM(Treatment_Cost) AS total_treatment_cost
FROM patients
GROUP BY YEAR(Admission_Date)
ORDER BY admission_year;
