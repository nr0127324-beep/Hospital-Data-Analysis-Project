Save your Excel inspection and Pivot Table workbook in this folder, for example hospital_analysis.xlsx.
